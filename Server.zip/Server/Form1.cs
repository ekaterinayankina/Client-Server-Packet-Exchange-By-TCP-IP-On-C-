﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
// добавленные
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;


namespace Server
{
    public partial class Form1 : Form
    {
        TcpListener listener;
        TcpClient client;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            listener = null;
            client = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int prt = 0;
            if (tport.Text == "")
            {
                MessageBox.Show("Порт пуст!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                prt = Convert.ToInt32(tport.Text);
                listener = new TcpListener(IPAddress.Any, prt);
                listener.Start();
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                textBox1.Text += "Ожидание клиента...\r\n";
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                client = listener.AcceptTcpClient();
                client.Client.SendTimeout = 20;
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                textBox1.Text += "Соединение установлено!\r\n";
                textBox1.Text += "Получение пакетов с 32 байт по 2 Кбайта запускается\r\n";
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                var recieveBytes = new byte[24576];
                int timeout = 16;
                for (int packet = 2048; packet <= 16384; packet*=2)
                {
                    for (int count=0; count <= Convert.ToDouble(16*1024/packet); count++)
                    {
                        client.GetStream().Read(recieveBytes, count * packet, packet);
                        textBox1.Text += "Пакет номер " + count + " размером " + packet + "  байт получен\r\n";
                    }
                    textBox1.Text += "--------------------------------------------------------------------\r\n";
                    textBox1.Text += "16 Кбайт пакетом " + packet + " байт получены успешно!\r\n";
                    textBox1.Text += "--------------------------------------------------------------------\r\n";
                }
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                textBox1.Text += "Отправка данных завершена!\r\n";
                textBox1.Text += "--------------------------------------------------------------------\r\n";
            }
            catch (SocketException e1)
            {
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                textBox1.Text += "SocketException: " + e1.Message + "\r\n";
                textBox1.Text += "--------------------------------------------------------------------\r\n";
            }
            finally
            {
                if (listener != null) listener.Stop();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
