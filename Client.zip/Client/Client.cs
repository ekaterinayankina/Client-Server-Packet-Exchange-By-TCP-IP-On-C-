﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Threading;

namespace Client
{
    class Program
    {
        static void Main()
        {
            var timer = new Stopwatch();
            //var hist = new Histogram();
            var sendBytes = new byte[24576];
            var rand = new Random();
            rand.NextBytes(sendBytes);
            int sizepacket = 512;
            int num = 24576 / sizepacket;
            Console.WriteLine("Введите IP адрес сервера");
            string ip = Console.ReadLine();
            try
            {
                if (ip != null)
                    using (var client = new TcpClient(ip, 5050))
                    {
                        for (int timeout = 5; timeout<20; timeout++ )
                        {
                            timer.Restart();
                            for (int packet = 0; packet < num; packet++)
                            {
                                client.GetStream().Write(sendBytes, packet * sizepacket, sizepacket);
                                Thread.Sleep(timeout);
                            }
                            timer.Stop();
                            Console.WriteLine("Передано 24 кб по " + sizepacket + " байт");
                            Console.WriteLine("Тайм-аут равен: {0}", timeout);
                            Console.WriteLine("Затрачено " + timer.ElapsedMilliseconds + " мс");
                            //hist.chart.Series["Series1"].Points.AddXY(sizepacket, timer.ElapsedMilliseconds);
                        }
                    }
                Console.WriteLine("Передача данных завершена!");
            }
            catch (SocketException e)
            {
                Console.WriteLine("SocketException: {0}", e.Message);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            //hist.ShowDialog();
            Console.ReadLine();
        }
    }
}

