﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//добавленные
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Threading;

namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
        const int n=7;
        long[] times=new long[n];
        int[] timeouts=new int[n];
        private void button1_Click(object sender, EventArgs e)
        {
            var timer = new Stopwatch();
            int i=0;
            var sendBytes = new byte[24576];
            var rand = new Random();
            rand.NextBytes(sendBytes);
            int timeout = 20;
            string ip;
            ip = tbIp.Text;
            if(ip=="")
            {
                MessageBox.Show("IP пуст!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if(tport.Text=="")
            {
                MessageBox.Show("Порм пуст!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int prt = 0;
            prt = Convert.ToInt32(tport.Text);
            try
            {
                if (ip != null)
                    using (var client = new TcpClient(ip, prt))
                    {
                        for (int packet = 2048; packet <= 16384; packet *= 2)
                        {
                            timer.Reset();
                            timer.Start();
                            for (int count = 0; count <= Convert.ToDouble(16 * 1024 / packet); count++)
                            {
                                client.GetStream().Write(sendBytes, count * packet, packet);
                                Thread.Sleep(timeout);
                            }
                            timer.Stop();
                            textBox1.Text += "--------------------------------------------------------------------\r\n";
                            textBox1.Text += "16 Кбайт пакетом " + packet + " байт отправлен\r\n";
                            textBox1.Text += timer.ElapsedMilliseconds + " мс прошло\r\n";
                            textBox1.Text += "--------------------------------------------------------------------\r\n";
                            times[i]=timer.ElapsedMilliseconds;
                            timeouts[i] = timeout;
                            i++;
                        }
                    }
                textBox1.Text += "Отправка данных завершена!\r\n";
                textBox1.Text += "--------------------------------------------------------------------\r\n";
            }
            catch (SocketException e1)
            {
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                textBox1.Text += "SocketException: " + e1.Message + "\r\n";
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                return;
            }
            catch (IOException e1)
            {
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                textBox1.Text += e1.Message + "\r\n";
                textBox1.Text += "--------------------------------------------------------------------\r\n";
                return;
            }
            button2.Enabled = true;
            pictureBox1.Visible = true;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Pen myPen = new Pen(Color.Black, 1);
            Rectangle[] recs = new Rectangle[n];
            int x = 0, y = 0;
            int Max = 0;
            int dt = 0;
            int[] packets = { 32, 64, 128, 256, 518, 1024, 2048, 0,0,0,0,0,0,0,0,0,0};
            int dx = pictureBox1.Size.Width / n;
            for (int i = 0; i < n; i++) if (times[i] > Max) Max = (int)times[i];
            string[] val = new string[n];
            Font MyFont = new Font("Microsoft Sans Serif", 10);
            SolidBrush fontbr = new SolidBrush(Color.Black);
            Point[] points = new Point[n];
            for (int i = 0; i < n; i++)
            {
                Random rnd = new Random();
                SolidBrush[] br = new SolidBrush[n];
                for (int j = 0; j < n; j++)
                {
                    br[j] = new SolidBrush(Color.FromArgb(rnd.Next(0, 255), rnd.Next(0, 255), rnd.Next(0, 255)));
                }
                dt = (int)times[i];
                y = pictureBox1.Size.Height - (((pictureBox1.Size.Height-30)*dt)/Max);
                recs[i] = new Rectangle(x, y, dx, pictureBox1.Size.Height);
                points[i] = new Point(x + 3, y - 15);
                e.Graphics.DrawString(Convert.ToString(times[i])+" мс", MyFont, fontbr, points[i]);
                points[i] = new Point(x + 3, y - 30);
                e.Graphics.DrawString(Convert.ToString(packets[i]) + " байт", MyFont, fontbr, points[i]);
                e.Graphics.FillRectangle(br[i], recs[i]);
                br[i].Dispose();
                x += dx;
            }
            e.Graphics.DrawRectangles(myPen, recs);
            myPen.Dispose();
            fontbr.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            pictureBox1.Visible = true;
        }

    }
}
